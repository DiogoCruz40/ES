import json
import boto3
import uuid
import base64
from decimal import Decimal

def lambda_handler(event, context):
    # TODO implement
    
   
    s3 = boto3.resource('s3')
    bucket_name = 'esbucketstatic'
    file_name_with_extention = uuid.uuid4().hex +'.jpeg'
    image_base64 = event['image'].split(';base64,')[1]
    
    obj = s3.Object(bucket_name,file_name_with_extention)
    obj.put(Body=base64.b64decode(image_base64))
        
 
    #get object url
    #object_url = "https://%s.s3.amazonaws.com/%s" % (bucket_name, file_name_with_extention)
    object_url = file_name_with_extention
    #print(object_url)

    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table("pratos")
    
    for obj in event['items']:
        obj['id_prato'] = uuid.uuid4().hex
        obj['id'] = Decimal(obj['id'])
        obj['price'] = Decimal(obj['price'])
        obj['locationtag'] = Decimal(event['locationtag'])
        obj['object_url'] = file_name_with_extention
        obj['statusoforder'] = 'comparing'
        obj['delivery'] = False
        obj['exec_name'] = event['exec_name']
        table.put_item(Item= obj)
        
    return {
        'object_url': object_url,
        'exec_name': event['exec_name']
    }
