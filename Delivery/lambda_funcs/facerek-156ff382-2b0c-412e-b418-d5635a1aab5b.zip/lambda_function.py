import json
import boto3

def lambda_handler(event, context):
    client = boto3.client('rekognition')
    
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table("pratos")
    responsedynamo = table.scan()
    data = responsedynamo['Items']
              
    while 'LastEvaluatedKey' in responsedynamo:
        responsedynamo = table.scan(ExclusiveStartKey=responsedynamo['LastEvaluatedKey'])
        data.extend(responsedynamo['Items'])
    
    s3 = boto3.client('s3')
    response = s3.list_objects_v2(
    Bucket='esbuckettarget'
    )
    
    for obj in response['Contents']:
        
        try:
            responsefaces = client.compare_faces(
            SourceImage={
            'S3Object': {
            'Bucket': 'esbucketstatic',
            'Name': event['object_url']
            }
            },
            TargetImage={
            'S3Object': {
            'Bucket': 'esbuckettarget',
            'Name': obj['Key']
            }
            },
            SimilarityThreshold=70
            )
            #print(response)
            
            resposta=responsefaces['FaceMatches']
            
            for record in resposta:
                face = record
                confidence=face['Face']
                #print ("Matched With {}""%"" Similarity".format(face['Similarity']))
                #print ("With {}""%"" Confidence".format(confidence['Confidence']))
                if face['Similarity'] > 90 and confidence['Confidence'] > 90 :
                    UpdateExpression = 'SET statusoforder = :val1'
                    ExpressionAttributeValues = {
                        ':val1': 'matched'
                    }
                    
                    for obj in data:
                        if(obj['object_url'] == event['object_url']):
                            table.update_item(
                                Key={
                                    'id_prato': obj['id_prato'] 
                                },
                                ConditionExpression= 'attribute_exists(id_prato)',
                                UpdateExpression=UpdateExpression,
                                ExpressionAttributeValues=ExpressionAttributeValues
                            )
                    return {
                        'status': 'matched',
                        'exec_name': event['exec_name'],
                        'object_url': event['object_url']
                    }
        except:
            pass
        
    UpdateExpression = 'SET statusoforder = :val1'
    ExpressionAttributeValues = {
        ':val1': 'nomatched'
    }
    
    for obj in data:
        if(obj['object_url'] == event['object_url']):
            table.update_item(
                Key={
                    'id_prato': obj['id_prato'] 
                },
                ConditionExpression= 'attribute_exists(id_prato)',
                UpdateExpression=UpdateExpression,
                ExpressionAttributeValues=ExpressionAttributeValues
            )
            
    return {
        'status': 'nomatched',
        'exec_name': event['exec_name'],
        'object_url': event['object_url']
    }