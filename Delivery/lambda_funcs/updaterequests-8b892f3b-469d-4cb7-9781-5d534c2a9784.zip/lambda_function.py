import json
import boto3

def lambda_handler(event, context):
    # TODO implement

    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table("pratos")
    response = table.scan()
    data = response['Items']
  
  
    while 'LastEvaluatedKey' in response:
        response = table.scan(ExclusiveStartKey=response['LastEvaluatedKey'])
        data.extend(response['Items'])
  
    UpdateExpression = 'SET delivery = :val1'
    ExpressionAttributeValues = {
        ':val1': True
    }
    
    for obj in data:
        if(obj['object_url'] == event['pedido']):
            table.update_item(
                Key={
                    'id_prato': obj['id_prato'] 
                },
                ConditionExpression= 'attribute_exists(id_prato)',
                UpdateExpression=UpdateExpression,
                ExpressionAttributeValues=ExpressionAttributeValues
            )
    return {
        'headers': {
            "Content-Type": "application/json"
        },
        'statusCode': 200,
    }
