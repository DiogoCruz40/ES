import json
import boto3
from boto3.dynamodb.conditions import Key, And
from functools import reduce

def lambda_handler(event, context):
  dynamodb = boto3.resource('dynamodb')

  table = dynamodb.Table('pratos')
  filters = dict()
  filters['exec_name'] = event['exec_name']
  #filters['statusoforder'] = "matched"
  
  response = table.scan(FilterExpression=reduce(And, ([Key(k).eq(v) for k, v in filters.items()])))
  data = response['Items']
  
  
  while 'LastEvaluatedKey' in response:
    response = table.scan(ExclusiveStartKey=response['LastEvaluatedKey'],FilterExpression=And(*[(Key(key).eq(value)) for key, value in filters.items()]))
    data.extend(response['Items'])
  
  for x in data:
    if(x["delivery"] == True):
      return {
        'delivery': True,
        'exec_name': event['exec_name'],
        'object_url': x["object_url"]
      }
    else:
      return {
        'delivery': False,
        'exec_name': event['exec_name'],
        'object_url': x["object_url"]
      }

