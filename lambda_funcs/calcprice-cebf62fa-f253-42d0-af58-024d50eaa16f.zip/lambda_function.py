import json

def lambda_handler(event, context):
    # TODO implement
    price = 0.0
    list = event['postdata']
    
    for obj in list:
        price = price + obj['price']
   
    return {
        'statusCode': 200,
        "headers": {
            "Content-Type": "application/json"
        },
        'body': price
    }
