import json
import boto3

def lambda_handler(event, context):
    
    client = boto3.client('rekognition')
    s3 = boto3.client('s3')
    response = s3.list_objects_v2(
    Bucket='esbuckettarget'
    )
    for obj in response['Contents']:
        response = client.compare_faces(
        SourceImage={
        'S3Object': {
        'Bucket': 'esbucketstatic',
        'Name': event['imagename']
        }
        },
        TargetImage={
        'S3Object': {
        'Bucket': 'esbuckettarget',
        'Name': obj['Key']
        }
        },
        SimilarityThreshold=70
        )
        #print(response)
        
        resposta=response['FaceMatches']
        
        for record in resposta:
            face = record
            confidence=face['Face']
            #print ("Matched With {}""%"" Similarity".format(face['Similarity']))
            #print ("With {}""%"" Confidence".format(confidence['Confidence']))
            if face['Similarity'] > 90 and confidence['Confidence'] > 90 :
                return {
                    'statusCode': 200,
                    'body': 'matched'
                }
            
        
    return {
        'statusCode': 200,
        'body': 'nomatched'
    }